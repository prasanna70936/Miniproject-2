package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repo;

    // Create/add a new product
    public Product add(Product p) {
        return repo.save(p);
    }

    // Update an existing product
    public Product update(Product p) {
        return repo.save(p);
    }

    // Delete a product by ID
    public void delete(Integer id) {
        repo.deleteById(id);
    }

    // Get a product by ID
    public Optional<Product> findById(Integer id) {
        return repo.findById(id);
    }

    // Get all products
    public List<Product> listAll() {
        return repo.findAll();
    }

    // Get products with quantity <= threshold
    public List<Product> stockAlert(int threshold) {
        return repo.findByQuantityLessThanEqual(threshold);
    }

    // Get products by exact name match
    public List<Product> findByName(String name) {
        return repo.findByName(name);
    }
}
