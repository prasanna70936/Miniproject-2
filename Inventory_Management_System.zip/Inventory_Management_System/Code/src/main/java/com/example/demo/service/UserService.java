package com.example.demo.service;

import com.example.demo.model.User;

import java.util.ArrayList;
import java.util.List;

public class UserService {
    private static List<User> users = new ArrayList<>();
    private static boolean loggedIn = false;

    // ✅ Signup method
    public String signup(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                return "❌ Username already exists!";
            }
        }
        users.add(new User(username, password));
        return "✅ Signup successful!";
    }

    // ✅ Login method
    public String login(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
                loggedIn = true;
                return "✅ Login successful!";
            }
        }
        return "❌ Invalid credentials!";
    }

    // ✅ Check login status
    public static boolean isLoggedIn() {
        return loggedIn;
    }

    // ✅ Get all users
    public List<User> getAllUsers() {
        return users;
    }

    // ✅ Get a user by username
    public User getUserByUsername(String username) {
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                return u;
            }
        }
        return null;
    }

    // ✅ Update a user (by username)
    public String updateUser(String oldUsername, String newUsername, String newPassword) {
        for (User u : users) {
            if (u.getUsername().equals(oldUsername)) {
                u.setUsername(newUsername);
                u.setPassword(newPassword);
                return "✅ User updated successfully!";
            }
        }
        return "❌ User not found!";
    }

    // ✅ Delete a user by username
    public String deleteUser(String username) {
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                users.remove(u);
                return "🗑️ User deleted successfully!";
            }
        }
        return "❌ User not found!";
    }
}
