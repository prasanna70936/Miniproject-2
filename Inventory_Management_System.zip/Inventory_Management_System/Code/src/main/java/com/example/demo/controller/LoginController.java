package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class LoginController {

    private final UserService userService = new UserService();

    // ✅ Signup endpoint
    @PostMapping("/signup")
    public String signup(@RequestBody User user) {
        return userService.signup(user.getUsername(), user.getPassword());
    }

    // ✅ Login endpoint
    @PostMapping("/login")
    public String login(@RequestBody User user) {
        String result = userService.login(user.getUsername(), user.getPassword());

        if (result.contains("Login successful")) {
            return result + "\n\nHere are the available operations:\n"
                    + "🔹 Add product       → POST   /api/products\n"
                    + "🔹 View all products → GET    /api/products\n"
                    + "🔹 Get product by ID → GET    /api/products/{id}\n"
                    + "🔹 Search products   → GET    /api/products/search?name=xyz\n"
                    + "🔹 Update product    → PUT    /api/products/{id}\n"
                    + "🔹 Delete product    → DELETE /api/products/{id}\n"
                    + "🔹 Stock alerts      → GET    /api/products/alerts?threshold=10\n"
                    + "🔹 View all users    → GET    /user/all\n"
                    + "🔹 View user         → GET    /user/{username}\n"
                    + "🔹 Update user       → PUT    /user/update\n"
                    + "🔹 Delete user       → DELETE /user/delete/{username}";
        }

        return result;
    }

    // ✅ Dashboard (protected)
    @GetMapping("/dashboard")
    public String dashboard() {
        if (UserService.isLoggedIn()) {
            return "🔐 Welcome to the dashboard!";
        } else {
            return "⛔ Please login to access the dashboard.";
        }
    }

    // ✅ Get all users
    @GetMapping("/all")
    public List<User> getAllUsers() {
        if (UserService.isLoggedIn()) {
            return userService.getAllUsers();
        } else {
            throw new RuntimeException("⛔ Access denied. Please login first.");
        }
    }

    // ✅ Get user by username
    @GetMapping("/{username}")
    public User getUserByUsername(@PathVariable String username) {
        if (UserService.isLoggedIn()) {
            User user = userService.getUserByUsername(username);
            if (user == null) {
                throw new RuntimeException("❌ User not found.");
            }
            return user;
        } else {
            throw new RuntimeException("⛔ Access denied. Please login first.");
        }
    }

    // ✅ Update user
    @PutMapping("/update")
    public String updateUser(@RequestParam String oldUsername,
                             @RequestParam String newUsername,
                             @RequestParam String newPassword) {
        if (UserService.isLoggedIn()) {
            return userService.updateUser(oldUsername, newUsername, newPassword);
        } else {
            return "⛔ Please login to update user information.";
        }
    }

    // ✅ Delete user
    @DeleteMapping("/delete/{username}")
    public String deleteUser(@PathVariable String username) {
        if (UserService.isLoggedIn()) {
            return userService.deleteUser(username);
        } else {
            return "⛔ Please login to delete a user.";
        }
    }
}
