package com.example.demo.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
	public class Product {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer id;

	    // existing fields...
	    private String name;
	    private String description;
	    private int quantity;
	    private int threshold;
	    private BigDecimal price;

	    // Manual getter and setter for 'id'
	    public Integer getId() {
	        return this.id;
	    }

	    public void setId(Integer id) {
	        this.id = id;
	    }

	    // You'll also need getters and setters for the other fields:
	    public String getName() {
	        return name;
	    }
	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getDescription() {
	        return description;
	    }
	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public int getQuantity() {
	        return quantity;
	    }
	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }

	    public int getThreshold() {
	        return threshold;
	    }
	    public void setThreshold(int threshold) {
	        this.threshold = threshold;
	    }

	    public BigDecimal getPrice() {
	        return price;
	    }
	    public void setPrice(BigDecimal price) {
	        this.price = price;
	    }
}