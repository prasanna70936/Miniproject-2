package com.example.demo.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
    // Existing method for threshold-based alerts
    List<Product> findByQuantityLessThanEqual(int threshold);

    // New method to fetch products by exact name match
    List<Product> findByName(String name);
}
