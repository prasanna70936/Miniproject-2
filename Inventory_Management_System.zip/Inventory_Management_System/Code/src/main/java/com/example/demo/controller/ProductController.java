package com.example.demo.controller;

import com.example.demo.model.Product;
import com.example.demo.service.ProductService;
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService service;

    private void checkLogin() {
        if (!UserService.isLoggedIn()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "❌ Invalid credentials. Please login.");
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Product create(@RequestBody Product product) {
        checkLogin();
        return service.add(product);
    }

    @GetMapping
    public List<Product> listAll() {
        checkLogin();
        return service.listAll();
    }

    @GetMapping("/{id}")
    public Product getById(@PathVariable Integer id) {
        checkLogin();
        return service.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found"));
    }

    @GetMapping("/search")
    public List<Product> getByName(@RequestParam String name) {
        checkLogin();
        List<Product> list = service.findByName(name);
        if (list.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No products found with name: " + name);
        }
        return list;
    }

    @PutMapping("/{id}")
    public Product update(@PathVariable Integer id, @RequestBody Product product) {
        checkLogin();
        product.setId(id);
        return service.update(product);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Integer id) {
        checkLogin();
        service.delete(id);
    }

    @GetMapping("/alerts")
    public List<Product> alerts(@RequestParam(name = "threshold", defaultValue = "0") int threshold) {
        checkLogin();
        return service.stockAlert(threshold);
    }

    @GetMapping("/all")
    public List<Product> getAllIfLoggedIn() {
        checkLogin();
        return service.listAll();
    }
}
